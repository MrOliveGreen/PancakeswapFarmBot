export default function isUndefinedOrNull(value: any): boolean {
  return value === null || value === undefined
}
