# @pancakeswap/utils

## 3.0.2

### Patch Changes

- Updated dependencies [e0a681bc6]
  - @pancakeswap/tokens@0.2.2
  - @pancakeswap/awgmi@0.1.8
  - @pancakeswap/localization@3.0.2
  - @pancakeswap/token-lists@0.0.8

## 3.0.1

### Patch Changes

- @pancakeswap/tokens@0.2.1
- @pancakeswap/awgmi@0.1.7
- @pancakeswap/localization@3.0.1
- @pancakeswap/token-lists@0.0.8

## 3.0.0

### Patch Changes

- Updated dependencies [77fc3406a]
  - @pancakeswap/tokens@0.2.0
  - @pancakeswap/awgmi@0.1.6
  - @pancakeswap/localization@3.0.0
  - @pancakeswap/token-lists@0.0.8

## 2.0.3

### Patch Changes

- Updated dependencies [500adb4f8]
  - @pancakeswap/tokens@0.1.6
  - @pancakeswap/awgmi@0.1.5
  - @pancakeswap/localization@2.0.3
  - @pancakeswap/token-lists@0.0.8

## 2.0.2

### Patch Changes

- @pancakeswap/tokens@0.1.5
- @pancakeswap/awgmi@0.1.4
- @pancakeswap/localization@2.0.2
- @pancakeswap/token-lists@0.0.8

## 2.0.1

### Patch Changes

- e31475e6b: chore: Bump up jotai
- Updated dependencies [e31475e6b]
  - @pancakeswap/token-lists@0.0.8
  - @pancakeswap/tokens@0.1.4
  - @pancakeswap/awgmi@0.1.3
  - @pancakeswap/localization@2.0.1

## 2.0.0

### Major Changes

- 938aa75f5: Migrate ethers to viem

### Patch Changes

- @pancakeswap/tokens@0.1.3
- @pancakeswap/awgmi@0.1.2
- @pancakeswap/localization@2.0.0
- @pancakeswap/token-lists@0.0.7

## 1.0.0

### Patch Changes

- Updated dependencies [b5dbd2921]
  - @pancakeswap/aptos-swap-sdk@1.0.0
  - @pancakeswap/tokens@0.1.2
  - @pancakeswap/token-lists@0.0.7
  - @pancakeswap/awgmi@0.1.1
  - @pancakeswap/localization@1.0.0
