# @pancakeswap/hooks

## 0.0.9

### Patch Changes

- @pancakeswap/utils@3.0.2

## 0.0.8

### Patch Changes

- @pancakeswap/utils@3.0.1

## 0.0.7

### Patch Changes

- @pancakeswap/utils@3.0.0

## 0.0.6

### Patch Changes

- @pancakeswap/utils@2.0.3

## 0.0.5

### Patch Changes

- @pancakeswap/utils@2.0.2

## 0.0.4

### Patch Changes

- Updated dependencies [e31475e6b]
  - @pancakeswap/utils@2.0.1

## 0.0.3

### Patch Changes

- Updated dependencies [938aa75f5]
  - @pancakeswap/utils@2.0.0

## 0.0.2

### Patch Changes

- Updated dependencies [b5dbd2921]
  - @pancakeswap/swap-sdk-core@1.0.0
  - @pancakeswap/utils@1.0.0
