# @pancakeswap/tokens

## 0.2.2

### Patch Changes

- e0a681bc6: Usd native USDC in Arbitrum
  - @pancakeswap/token-lists@0.0.8

## 0.2.1

### Patch Changes

- Updated dependencies [3ba496cb1]
  - @pancakeswap/sdk@5.2.1
  - @pancakeswap/token-lists@0.0.8

## 0.2.0

### Minor Changes

- 77fc3406a: Add zkSync support

### Patch Changes

- Updated dependencies [77fc3406a]
  - @pancakeswap/sdk@5.2.0
  - @pancakeswap/token-lists@0.0.8

## 0.1.6

### Patch Changes

- 500adb4f8: Add new tokens
  - @pancakeswap/token-lists@0.0.8

## 0.1.5

### Patch Changes

- Updated dependencies [f9fda4ebe]
  - @pancakeswap/sdk@5.1.0
  - @pancakeswap/token-lists@0.0.8

## 0.1.4

### Patch Changes

- Updated dependencies [e31475e6b]
  - @pancakeswap/token-lists@0.0.8

## 0.1.3

### Patch Changes

- Updated dependencies [938aa75f5]
  - @pancakeswap/sdk@5.0.0
  - @pancakeswap/token-lists@0.0.7

## 0.1.2

### Patch Changes

- Updated dependencies [b5dbd2921]
  - @pancakeswap/sdk@4.0.0
  - @pancakeswap/token-lists@0.0.7

## 0.1.1

### Patch Changes

- 77e056357: Remove private flag

## 0.1.0

### Minor Changes

- 65fbb250a: Bump version

### Patch Changes

- Updated dependencies [65fbb250a]
  - @pancakeswap/sdk@3.2.0
