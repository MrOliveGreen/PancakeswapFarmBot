# @pancakeswap/token-lists

## 0.0.8

### Patch Changes

- e31475e6b: chore: Bump up jotai

## 0.0.7

### Patch Changes

- Updated dependencies [b5dbd2921]
  - @pancakeswap/swap-sdk-core@1.0.0

## 0.0.6

### Patch Changes

- d5bf9101d: chore: Bump up jotai

## 0.0.5

### Patch Changes

- 80e616be0: fix: Filter out tokeen with empty symbol in tokenlists

## 0.0.4

### Patch Changes

- 5dda2c74f: Fix duplicate active list url issue

## 0.0.3

### Patch Changes

- 64dbde8e2: Fix token list getting from indexeddb not updating when version bump

## 0.0.2

### Patch Changes

- 68440160d: ## PancakeSwap version spec
  Add `schema` aptos to indentify aptos version of token list
  without schema will default be uniswap version evm validation
