import { SerializedFarmConfig } from '../..'

const priceHelperLps: SerializedFarmConfig[] = []

export default priceHelperLps
