# @pancakeswap/swap-sdk-core

## 1.0.0

### Major Changes

- b5dbd2921: Remove JSBI and use BigInt native instead

## 0.1.0

### Minor Changes

- 65fbb250a: Bump version
