import { PoolProvider } from '../../types'

export function createPoolProviderWithCache(provider: PoolProvider): PoolProvider {
  // TODO add caching strategies
  return provider
}
