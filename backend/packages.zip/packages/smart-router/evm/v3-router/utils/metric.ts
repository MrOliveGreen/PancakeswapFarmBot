import debug from 'debug'

export const metric = debug('smart-router:metric')
export const log = debug('smart-router:log')
