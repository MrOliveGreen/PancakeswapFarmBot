import { getMidPrice } from './utils/route'

export const Route = {
  midPrice: getMidPrice,
}
