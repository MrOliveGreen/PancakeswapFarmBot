# @pancakeswap/awgmi

## 0.1.8

### Patch Changes

- @pancakeswap/utils@3.0.2

## 0.1.7

### Patch Changes

- @pancakeswap/utils@3.0.1

## 0.1.6

### Patch Changes

- @pancakeswap/utils@3.0.0

## 0.1.5

### Patch Changes

- @pancakeswap/utils@2.0.3

## 0.1.4

### Patch Changes

- @pancakeswap/utils@2.0.2

## 0.1.3

### Patch Changes

- Updated dependencies [e31475e6b]
  - @pancakeswap/utils@2.0.1

## 0.1.2

### Patch Changes

- Updated dependencies [938aa75f5]
  - @pancakeswap/utils@2.0.0

## 0.1.1

### Patch Changes

- @pancakeswap/utils@1.0.0

## 0.1.0

### Minor Changes

- e589ebd1c: Add Rise wallet connector

## 0.0.11

### Patch Changes

- e68ad6524: Add missing chains on connect

## 0.0.10

### Patch Changes

- 2763b05af: Catch more wallets user reject error for Petra, Martian, Blocto, Pontem

## 0.0.9

### Patch Changes

- ae6ed2811: - Add getTableItem core
  - parseVmStatusError vm in simulation error by default

## 0.0.8

### Patch Changes

- a584ca7aa: Consolidate Fewcha error
- 229d07513: Add Fewcha tx options

## 0.0.7

### Patch Changes

- 40ea8c1ee: Integrate Fewcha wallet event

## 0.0.6

### Patch Changes

- 7ecd15d9e: Add SafePal connector
  Allow override Martian connector id and name. To keep both connector compatiable, avoid using `generateSignAndSubmitTransaction`
- b57ae08cb: Update blocto sdk

## 0.0.5

### Patch Changes

- e62e71c8d: Allow petra connector id override
