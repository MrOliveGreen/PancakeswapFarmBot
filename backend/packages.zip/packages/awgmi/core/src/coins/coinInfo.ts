export const wrapCoinInfoTypeTag = (type: string) => `0x1::coin::CoinInfo<${type}>`
