/* eslint-disable import/extensions */
import * as pkg from 'use-sync-external-store/shim/index.js'

// eslint-disable-next-line prefer-destructuring
export const useSyncExternalStore = pkg.useSyncExternalStore
