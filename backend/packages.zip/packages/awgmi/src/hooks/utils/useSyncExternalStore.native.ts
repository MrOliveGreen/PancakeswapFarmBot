// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
// eslint-disable-next-line import/extensions
import * as pkg from 'use-sync-external-store/shim/index.native.js'

// eslint-disable-next-line prefer-destructuring
export const useSyncExternalStore = pkg.useSyncExternalStore
