# @pancakeswap/aptos-swap-sdk

## 1.0.0

### Major Changes

- b5dbd2921: Remove JSBI and use BigInt native instead

### Patch Changes

- Updated dependencies [b5dbd2921]
  - @pancakeswap/swap-sdk-core@1.0.0

## 0.0.2

### Patch Changes

- dae8701b5: Fix APT coin compare

## 0.0.1

### Patch Changes

- bcba002d7: Aptos swap sdk release
