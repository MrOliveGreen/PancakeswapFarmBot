import type { AptosCoin } from './aptosCoin'
import type { Coin } from './coin'

export type Currency = AptosCoin | Coin
